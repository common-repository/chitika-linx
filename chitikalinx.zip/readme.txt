==== Chitika Linx plugin for WordPress

Chitika linx plugin allows you to put Chitika Linx in your Wordpress Blog. 
Chitika Linx are inline text ads which can earn you money when clicked on.

Plugin Name: Chitika Linx
Plugin URI: http://www.programmershelp.net/chitikalinx.php
Description: This plugin adds the Chitika Linx code to your blog
Version: 0.2
Author: IH
Author URI: http://www.programmershelp.net

==== Installation & Usage 

1. Upload the  plugin to your /wp-content/plugins/ folder.
2. Go to the Plugins page and activate the plugin.
3. In the Options tab click on Chitika Linx and enter your affiliate ID from Chitika and then click on Update Options.
4. Optional : You can enter a Channel ID for reporting purposes by entering a value in the Channel ID text box
   
=== Changelog

Feb 08th, 2008 v0.1 : Basic first release.
Feb 12th, 2008 v0.2 : Better Chitika ID compatability and the ability to include a Tracking Channel for reports


==== Copyright (c) 2008  phelp  www.programmershelp.net

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details:
http://www.gnu.org/licenses/gpl.txt